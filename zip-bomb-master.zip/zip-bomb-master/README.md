zip-bomb
========

scripts to create zip bombs

example of script from 'Web Security Testing Cookbook' rewritten in python
